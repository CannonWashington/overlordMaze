using WebSocketSharp;
using UnityEngine;

public class WS_Client : MonoBehaviour
{
    string commandString;
    GameObject targetObject;
    WebSocket ws;
    bool oneOn = true;
    bool twoOn = true;
    bool threeOn = true;
    void Start()
    {
        ws = new WebSocket("ws://localhost:8080");
        ws.OnMessage += (sender, e) =>
        {
            Debug.Log("Message received from " + ((WebSocket)sender).Url + ", Data : " + e.Data);
            commandString = e.Data;
        };
        ws.Connect();
    }


    void Update()
    {
        if(ws == null) return;
        switch (commandString) 
        {
            case "W1":
                targetObject = GameObject.Find("obstOne");
                if (oneOn == true) 
                {
                    targetObject.transform.position = new Vector3((float)11.85, (float)3.48, (float)12.5);
                    oneOn = false;
                }
                else if (oneOn == false) 
                {
                    targetObject.transform.position = new Vector3((float)11.85, (float)3.48, (float)8.5);
                    oneOn = true;
                }                
                break;
            case "W2":
                targetObject = GameObject.Find("obstTwo");
                if (twoOn == true)
                {
                    targetObject.transform.position = new Vector3(-2, -2, -2);
                    twoOn = false;
                }
                else if (twoOn == false)
                {
                    targetObject.transform.position = new Vector3((float)32.45, (float)3.48, (float)21.51);
                    twoOn = true;
                }
                break;
            default: break;
        }
        commandString = null;


        if(Input.GetKeyDown(KeyCode.W) | Input.GetKeyDown(KeyCode.UpArrow)) 
        {
            ws.Send("Up");
        }
        if(Input.GetKeyDown(KeyCode.S) | Input.GetKeyDown(KeyCode.DownArrow)) 
        {
            ws.Send("Down");
        }
        if (Input.GetKeyDown(KeyCode.A) | Input.GetKeyDown(KeyCode.LeftArrow))
        {
            ws.Send("Left");
        }
        if (Input.GetKeyDown(KeyCode.D) | Input.GetKeyDown(KeyCode.RightArrow))
        {
            ws.Send("Right");
        }
    }
}